package com.example.RightRide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RightRideApplication {

	public static void main(String[] args) {
		SpringApplication.run(RightRideApplication.class, args);
	}

}
