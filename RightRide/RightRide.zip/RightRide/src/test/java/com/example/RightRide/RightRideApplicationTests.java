package com.example.RightRide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RightRideApplicationTests {

	@Test
	void contextLoads() {
	}

}
